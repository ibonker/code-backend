package pers.fj.staffmanage.controller.v1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbDepartDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.entity.staff.manage.TbDepartPO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** 
 * 控制器的声明接口，可以与FeignClient配合使用 
 * 
 * @author Hotpotmaterial-Code2
 */
@Api(value = "TbDeparts")
@RequestMapping(value = "/staffmanage/api/v1")
public interface TbDepartsApi {
  
  /**
   * 实体staff.manage.TbDepartPO新增
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO新增", notes = "实体staff.manage.TbDepartPO新增", response = ResultOfTbDepartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbDepartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbDepartsPost(@ApiParam(value = "tbDepart", required = true) @RequestBody TbDepartPO tbDepart);
  /**
   * 实体staff.manage.TbDepartPO的json-schema
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO的json-schema", notes = "实体staff.manage.TbDepartPO的json-schema", response = ResultJsonSchemaDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultJsonSchemaDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs", produces = {"application/schema+json"},
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbDepartsGet(HttpServletRequest req);
  /**
   * 实体staff.manage.TbDepartPO的Excel导入
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO的Excel导入", notes = "实体staff.manage.TbDepartPO的Excel导入", response = ResultOfExcelReportDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfExcelReportDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs/import/excel", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,consumes = {"multipart/form-data"},
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbDepartsPost(@ApiParam(value = "excelDTO", required = true)  ExcelImportDTO excelDTO);
  /**
   * 实体staff.manage.TbDepartPO分页列表
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO分页列表", notes = "实体staff.manage.TbDepartPO分页列表", response = ResultPageDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultPageDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs/pages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbDepartsPagesPost(@ApiParam(value = "searchParams", required = true) @RequestBody PageDTO searchParams);
  /**
   * 实体staff.manage.TbDepartPO详情
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO详情", notes = "实体staff.manage.TbDepartPO详情", response = ResultOfTbDepartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbDepartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs/{tbDepartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbDepartsGET(@ApiParam(value = "tbDepartId", required = true) @PathVariable String tbDepartId);
  /**
   * 实体staff.manage.TbDepartPO删除
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO删除", notes = "实体staff.manage.TbDepartPO删除", response = ResultOfTbDepartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbDepartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs/{tbDepartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.DELETE)
  ResponseEntity<ResultDTO> tbDepartsDelete(@ApiParam(value = "tbDepartId", required = true) @PathVariable String tbDepartId);
  /**
   * 实体staff.manage.TbDepartPO更新
   */
  @ApiOperation(value = "实体staff.manage.TbDepartPO更新", notes = "实体staff.manage.TbDepartPO更新", response = ResultOfTbDepartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbDepartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_departs/{tbDepartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.PUT)
  ResponseEntity<ResultDTO> tbDepartsPut(@ApiParam(value = "tbDepartId", required = true) @PathVariable String tbDepartId, @ApiParam(value = "tbDepart", required = true) @RequestBody TbDepartPO tbDepart);
  
}