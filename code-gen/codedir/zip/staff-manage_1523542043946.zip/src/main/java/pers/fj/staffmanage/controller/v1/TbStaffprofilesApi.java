package pers.fj.staffmanage.controller.v1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbStaffprofileDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** 
 * 控制器的声明接口，可以与FeignClient配合使用 
 * 
 * @author Hotpotmaterial-Code2
 */
@Api(value = "TbStaffprofiles")
@RequestMapping(value = "/staffmanage/api/v1")
public interface TbStaffprofilesApi {
  
  /**
   * 实体staff.manage.TbStaffprofilePO新增
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO新增", notes = "实体staff.manage.TbStaffprofilePO新增", response = ResultOfTbStaffprofileDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffprofileDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffprofilesPost(@ApiParam(value = "tbStaffprofile", required = true) @RequestBody TbStaffprofilePO tbStaffprofile);
  /**
   * 实体staff.manage.TbStaffprofilePO的json-schema
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO的json-schema", notes = "实体staff.manage.TbStaffprofilePO的json-schema", response = ResultJsonSchemaDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultJsonSchemaDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles", produces = {"application/schema+json"},
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbStaffprofilesGet(HttpServletRequest req);
  /**
   * 实体staff.manage.TbStaffprofilePO的Excel导入
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO的Excel导入", notes = "实体staff.manage.TbStaffprofilePO的Excel导入", response = ResultOfExcelReportDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfExcelReportDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles/import/excel", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,consumes = {"multipart/form-data"},
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffprofilesPost(@ApiParam(value = "excelDTO", required = true)  ExcelImportDTO excelDTO);
  /**
   * 实体staff.manage.TbStaffprofilePO分页列表
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO分页列表", notes = "实体staff.manage.TbStaffprofilePO分页列表", response = ResultPageDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultPageDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles/pages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffprofilesPagesPost(@ApiParam(value = "searchParams", required = true) @RequestBody PageDTO searchParams);
  /**
   * 实体staff.manage.TbStaffprofilePO详情
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO详情", notes = "实体staff.manage.TbStaffprofilePO详情", response = ResultOfTbStaffprofileDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffprofileDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles/{tbStaffprofileId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbStaffprofilesGET(@ApiParam(value = "tbStaffprofileId", required = true) @PathVariable String tbStaffprofileId);
  /**
   * 实体staff.manage.TbStaffprofilePO更新
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO更新", notes = "实体staff.manage.TbStaffprofilePO更新", response = ResultOfTbStaffprofileDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffprofileDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles/{tbStaffprofileId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.PUT)
  ResponseEntity<ResultDTO> tbStaffprofilesPut(@ApiParam(value = "tbStaffprofileId", required = true) @PathVariable String tbStaffprofileId, @ApiParam(value = "tbStaffprofile", required = true) @RequestBody TbStaffprofilePO tbStaffprofile);
  /**
   * 实体staff.manage.TbStaffprofilePO删除
   */
  @ApiOperation(value = "实体staff.manage.TbStaffprofilePO删除", notes = "实体staff.manage.TbStaffprofilePO删除", response = ResultOfTbStaffprofileDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffprofileDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffprofiles/{tbStaffprofileId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.DELETE)
  ResponseEntity<ResultDTO> tbStaffprofilesDelete(@ApiParam(value = "tbStaffprofileId", required = true) @PathVariable String tbStaffprofileId);
  
}