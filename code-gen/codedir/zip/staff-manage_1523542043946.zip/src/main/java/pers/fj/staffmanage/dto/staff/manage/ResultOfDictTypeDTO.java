package pers.fj.staffmanage.dto.staff.manage;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.entity.staff.manage.DictTypePO;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

 /**
  * @author Hotpotmaterial-Code2
  *  staff.manage.DictTypePO详情实体
  */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonInclude(Include.NON_NULL)
public class ResultOfDictTypeDTO extends ResultDTO{

	@JsonProperty(value = "dictType")
	@JsonPropertyDescription("dict_type对象")				
	@ApiModelProperty(value = "dict_type对象")
	private DictTypePO dictType;
	

	public ResultOfDictTypeDTO dictType (DictTypePO dictType){
	  this.dictType = dictType;
	  return this;
	}
}