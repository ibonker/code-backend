package pers.fj.staffmanage.controller.v1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import pers.fj.staffmanage.dto.staff.manage.ResultOfTbPartDTO;
import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPartPO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** 
 * 控制器的声明接口，可以与FeignClient配合使用 
 * 
 * @author Hotpotmaterial-Code2
 */
@Api(value = "TbParts")
@RequestMapping(value = "/staffmanage/api/v1")
public interface TbPartsApi {
  
  /**
   * 实体staff.manage.TbPartPO新增
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO新增", notes = "实体staff.manage.TbPartPO新增", response = ResultOfTbPartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPartsPost(@ApiParam(value = "tbPart", required = true) @RequestBody TbPartPO tbPart);
  /**
   * 实体staff.manage.TbPartPO的json-schema
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO的json-schema", notes = "实体staff.manage.TbPartPO的json-schema", response = ResultJsonSchemaDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultJsonSchemaDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts", produces = {"application/schema+json"},
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbPartsGet(HttpServletRequest req);
  /**
   * 实体staff.manage.TbPartPO的Excel导入
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO的Excel导入", notes = "实体staff.manage.TbPartPO的Excel导入", response = ResultOfExcelReportDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfExcelReportDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts/import/excel", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,consumes = {"multipart/form-data"},
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPartsPost(@ApiParam(value = "excelDTO", required = true)  ExcelImportDTO excelDTO);
  /**
   * 实体staff.manage.TbPartPO分页列表
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO分页列表", notes = "实体staff.manage.TbPartPO分页列表", response = ResultPageDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultPageDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts/pages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPartsPagesPost(@ApiParam(value = "searchParams", required = true) @RequestBody PageDTO searchParams);
  /**
   * 实体staff.manage.TbPartPO删除
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO删除", notes = "实体staff.manage.TbPartPO删除", response = ResultOfTbPartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts/{tbPartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.DELETE)
  ResponseEntity<ResultDTO> tbPartsDelete(@ApiParam(value = "tbPartId", required = true) @PathVariable String tbPartId);
  /**
   * 实体staff.manage.TbPartPO更新
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO更新", notes = "实体staff.manage.TbPartPO更新", response = ResultOfTbPartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts/{tbPartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.PUT)
  ResponseEntity<ResultDTO> tbPartsPut(@ApiParam(value = "tbPartId", required = true) @PathVariable String tbPartId, @ApiParam(value = "tbPart", required = true) @RequestBody TbPartPO tbPart);
  /**
   * 实体staff.manage.TbPartPO详情
   */
  @ApiOperation(value = "实体staff.manage.TbPartPO详情", notes = "实体staff.manage.TbPartPO详情", response = ResultOfTbPartDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPartDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_parts/{tbPartId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbPartsGET(@ApiParam(value = "tbPartId", required = true) @PathVariable String tbPartId);
  
}