package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "ui_config")
public class UiConfigPO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  
  @Size(max = 16777215)
  @Column(name = "config_json")
  @JsonProperty(value = "configJson")
  @JsonPropertyDescription("")
  private String configJson;
  
  @Size(max = 64)
  @Column(name = "created_by")
  @JsonProperty(value = "createdBy")
  @JsonPropertyDescription("")
  private String createdBy;
  
  
  @Size(max = 64)
  @Column(name = "updated_by")
  @JsonProperty(value = "updatedBy")
  @JsonPropertyDescription("")
  private String updatedBy;
  
  
  
}