package pers.fj.staffmanage.controller.v1.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import pers.fj.staffmanage.controller.base.BaseController;
import pers.fj.staffmanage.common.RestStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.service.staff.manage.ITbDepartService;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbDepartDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.entity.staff.manage.TbDepartPO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import pers.fj.staffmanage.controller.v1.TbDepartsApi;

/** 
 * 控制器实现类
 * @author Hotpotmaterial-Code2
 */
@Controller
public class TbDepartsApiController extends BaseController implements TbDepartsApi {

  // 注入业务bean - ITbDepartService
  @Autowired
  private ITbDepartService tbDepartService;
  
  /**
   * 实体staff.manage.TbDepartPO新增
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsPost(@RequestBody TbDepartPO tbDepart) {
    tbDepartService.insertTbDepart(tbDepart);
    return new ResponseEntity<ResultDTO>(new ResultOfTbDepartDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO的json-schema
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsGet(HttpServletRequest req) {
    return new ResponseEntity<ResultDTO>(new ResultJsonSchemaDTO()
        .jsonSchema(tbDepartService.getTbDepartJsonSchema(req.getRequestURI()))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO的Excel导入
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsPost( ExcelImportDTO excelDTO) {
    return new ResponseEntity<ResultDTO>(new ResultOfExcelReportDTO().excelReport(tbDepartService.importExcelTbDepart(excelDTO))
        .message(RestStatus.RESULT_SUCCESS.message()).statusCode(RestStatus.RESULT_SUCCESS.code()),
        HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO分页列表
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsPagesPost(@RequestBody PageDTO searchParams) {
    return new ResponseEntity<ResultDTO>(tbDepartService.getTbDepartList(searchParams)
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO详情
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsGET(@PathVariable String tbDepartId) {
    return new ResponseEntity<ResultDTO>(new ResultOfTbDepartDTO()
        .tbDepart(tbDepartService.findById(tbDepartId))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO删除
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsDelete(@PathVariable String tbDepartId) {
    tbDepartService.deleteById(tbDepartId);
    return new ResponseEntity<ResultDTO>(new ResultDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbDepartPO更新
   */
  @Override
  public ResponseEntity<ResultDTO> tbDepartsPut(@PathVariable String tbDepartId, @RequestBody TbDepartPO tbDepart) {
    tbDepartService.updateTbDepart(tbDepartId, tbDepart);
    return new ResponseEntity<ResultDTO>(new ResultOfTbDepartDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  
}