package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "tb_part")
public class TbPartPO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  @NotNull
  @Size(max = 64)
  @Column(name = "staff_id")
  @JsonProperty(value = "staffId")
  @JsonPropertyDescription("")
  private String staffId;
  
  @NotNull
  @Size(max = 64)
  @Column(name = "post_id")
  @JsonProperty(value = "postId")
  @JsonPropertyDescription("")
  private String postId;
  
  
}