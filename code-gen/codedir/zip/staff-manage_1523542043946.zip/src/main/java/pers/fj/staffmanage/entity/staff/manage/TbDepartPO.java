package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "tb_depart")
public class TbDepartPO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  
  @Size(max = 255)
  @Column(name = "depart_describ")
  @JsonProperty(value = "departDescrib")
  @JsonPropertyDescription("")
  private String departDescrib;
  
  @NotNull
  @Size(max = 255)
  @Column(name = "depart_name")
  @JsonProperty(value = "departName")
  @JsonPropertyDescription("")
  private String departName;
  
  @NotNull
  @Size(max = 255)
  @Column(name = "high_depart_id")
  @JsonProperty(value = "highDepartId")
  @JsonPropertyDescription("")
  private String highDepartId;
  
  
}