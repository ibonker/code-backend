package pers.fj.staffmanage.service.uiconfig.impl;

import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.hotpotmaterial.anywhere.common.utils.FileUtils;
import pers.fj.staffmanage.common.RestStatus;
import pers.fj.staffmanage.exception.CodeCommonException;
import pers.fj.staffmanage.service.uiconfig.IUiConfigService;
import pers.fj.staffmanage.service.uiconfig.impl.UICache;
import pers.fj.staffmanage.entity.staff.manage.UiConfigPO;
	
	
/**
 * 前端配置文件业务接口声明实现类（文件保存）
 * @author Hotpotmaterial-Code2
 */
@Service("UiConfigService")
public class UiConfigServiceImpl implements IUiConfigService {
  
  // 注入缓存bean
  @Autowired
  private UICache uiCache;

  // 注入mapper
  @Autowired
  private UiConfigPOMapper uiConfigPOMapper;

  // 根据版本获取ui配置
  @Override
  public Map<String, Object> getUiConfig(String version) {
    // 如果版本号相同返回空,否则返回内存数据
    if (uiCache.getUIMap().get("version").toString().equals(version)) {
      return null;
    } else {
      return uiCache.getUIMap();
    }
  }
  
  // 保存数据
  @Override
  public void saveUiConfig(String data) {
    // 获取内存版本号
    int version = Integer.valueOf(uiCache.getUIMap().get("version").toString());
    UiConfigPO configObj = this.findById("all");
    if (null != configObj) {
      configObj.setConfigJson(data.replace("'", "\""));
      this.updateUiConfig(configObj.getId(), configObj);
    } else {
      configObj = new UiConfigPO();
      configObj.setConfigJson(data.replace("'", "\""));
      configObj.setId("all");
      this.insertUiConfig(configObj);
    }
    // 更新内存数据
    uiCache.saveUiMap(configObj);
    // 更新内存版本号
    uiCache.getUIMap().put("version", version + 1);
  }

  //新增
  @Override
  public int insertUiConfig(UiConfigPO uiConfig) {
    // 设置值
    uiConfig.preInsert();
    return uiConfigPOMapper.insertSelective(uiConfig);
  }

  //修改
  @Override
  public int updateUiConfig(String id, UiConfigPO uiConfig) {
    uiConfig.preUpdate();
    uiConfig.setId(id);
    return uiConfigPOMapper.updateByPrimaryKeySelective(uiConfig);
  }

}