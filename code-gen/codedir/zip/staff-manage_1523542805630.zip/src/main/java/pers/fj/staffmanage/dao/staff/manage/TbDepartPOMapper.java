package pers.fj.staffmanage.dao.staff.manage;

import java.util.List;
import pers.fj.staffmanage.entity.staff.manage.TbDepartPO;
import pers.fj.staffmanage.entity.staff.manage.TbDepartPOExample;

public interface TbDepartPOMapper {
    int deleteByExample(TbDepartPOExample example);

    int deleteByPrimaryKey(String id);

    int insert(TbDepartPO record);

    int insertSelective(TbDepartPO record);

    List<TbDepartPO> selectByExample(TbDepartPOExample example);

    TbDepartPO selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TbDepartPO record);

    int updateByPrimaryKey(TbDepartPO record);
}