package pers.fj.staffmanage.controller.v1.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import pers.fj.staffmanage.controller.base.BaseController;
import pers.fj.staffmanage.common.RestStatus;
import org.springframework.web.bind.annotation.RequestBody;
import pers.fj.staffmanage.service.staff.manage.ITbStaffService;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import pers.fj.staffmanage.entity.staff.manage.TbStaffPO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbStaffDTO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import pers.fj.staffmanage.controller.v1.TbStaffsApi;

/** 
 * 控制器实现类
 * @author Hotpotmaterial-Code2
 */
@Controller
public class TbStaffsApiController extends BaseController implements TbStaffsApi {

  // 注入业务bean - ITbStaffService
  @Autowired
  private ITbStaffService tbStaffService;
  
  /**
   * 实体staff.manage.TbStaffPO新增
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsPost(@RequestBody TbStaffPO tbStaff) {
    tbStaffService.insertTbStaff(tbStaff);
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO的json-schema
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsGet(HttpServletRequest req) {
    return new ResponseEntity<ResultDTO>(new ResultJsonSchemaDTO()
        .jsonSchema(tbStaffService.getTbStaffJsonSchema(req.getRequestURI()))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO的Excel导入
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsPost( ExcelImportDTO excelDTO) {
    return new ResponseEntity<ResultDTO>(new ResultOfExcelReportDTO().excelReport(tbStaffService.importExcelTbStaff(excelDTO))
        .message(RestStatus.RESULT_SUCCESS.message()).statusCode(RestStatus.RESULT_SUCCESS.code()),
        HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO分页列表
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsPagesPost(@RequestBody PageDTO searchParams) {
    return new ResponseEntity<ResultDTO>(tbStaffService.getTbStaffList(searchParams)
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO更新
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsPut(@PathVariable String tbStaffId, @RequestBody TbStaffPO tbStaff) {
    tbStaffService.updateTbStaff(tbStaffId, tbStaff);
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO删除
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsDelete(@PathVariable String tbStaffId) {
    tbStaffService.deleteById(tbStaffId);
    return new ResponseEntity<ResultDTO>(new ResultDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffPO详情
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffsGET(@PathVariable String tbStaffId) {
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffDTO()
        .tbStaff(tbStaffService.findById(tbStaffId))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  
}