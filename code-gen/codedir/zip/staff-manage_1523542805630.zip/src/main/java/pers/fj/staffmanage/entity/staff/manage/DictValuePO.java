package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "dict_value")
public class DictValuePO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  
  @NotNull
  @Size(max = 64)
  @Column(name = "name")
  @JsonProperty(value = "name")
  @JsonPropertyDescription("")
  private String name;
  
  @NotNull
  @Size(max = 255)
  @Column(name = "value")
  @JsonProperty(value = "value")
  @JsonPropertyDescription("")
  private String value;
  
  @NotNull
  @Size(max = 64)
  @Column(name = "dict_code")
  @JsonProperty(value = "dictCode")
  @JsonPropertyDescription("")
  private String dictCode;
  
  @Column(name = "sort")
  @JsonProperty(value = "sort")
  @JsonPropertyDescription("")
  private Integer sort;
  
  @Size(max = 64)
  @Column(name = "created_by")
  @JsonProperty(value = "createdBy")
  @JsonPropertyDescription("")
  private String createdBy;
  
  
  @Size(max = 64)
  @Column(name = "updated_by")
  @JsonProperty(value = "updatedBy")
  @JsonPropertyDescription("")
  private String updatedBy;
  
  
  @Size(max = 1)
  @Column(name = "del_flag")
  @JsonProperty(value = "delFlag")
  @JsonPropertyDescription("")
  private String delFlag;
  
  
}