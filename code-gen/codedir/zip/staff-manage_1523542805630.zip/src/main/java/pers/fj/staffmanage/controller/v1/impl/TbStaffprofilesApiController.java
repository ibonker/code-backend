package pers.fj.staffmanage.controller.v1.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import pers.fj.staffmanage.controller.base.BaseController;
import pers.fj.staffmanage.common.RestStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbStaffprofileDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.service.staff.manage.ITbStaffprofileService;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import pers.fj.staffmanage.controller.v1.TbStaffprofilesApi;

/** 
 * 控制器实现类
 * @author Hotpotmaterial-Code2
 */
@Controller
public class TbStaffprofilesApiController extends BaseController implements TbStaffprofilesApi {

  // 注入业务bean - ITbStaffprofileService
  @Autowired
  private ITbStaffprofileService tbStaffprofileService;
  
  /**
   * 实体staff.manage.TbStaffprofilePO新增
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesPost(@RequestBody TbStaffprofilePO tbStaffprofile) {
    tbStaffprofileService.insertTbStaffprofile(tbStaffprofile);
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffprofileDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO的json-schema
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesGet(HttpServletRequest req) {
    return new ResponseEntity<ResultDTO>(new ResultJsonSchemaDTO()
        .jsonSchema(tbStaffprofileService.getTbStaffprofileJsonSchema(req.getRequestURI()))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO的Excel导入
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesPost( ExcelImportDTO excelDTO) {
    return new ResponseEntity<ResultDTO>(new ResultOfExcelReportDTO().excelReport(tbStaffprofileService.importExcelTbStaffprofile(excelDTO))
        .message(RestStatus.RESULT_SUCCESS.message()).statusCode(RestStatus.RESULT_SUCCESS.code()),
        HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO分页列表
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesPagesPost(@RequestBody PageDTO searchParams) {
    return new ResponseEntity<ResultDTO>(tbStaffprofileService.getTbStaffprofileList(searchParams)
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO详情
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesGET(@PathVariable String tbStaffprofileId) {
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffprofileDTO()
        .tbStaffprofile(tbStaffprofileService.findById(tbStaffprofileId))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO更新
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesPut(@PathVariable String tbStaffprofileId, @RequestBody TbStaffprofilePO tbStaffprofile) {
    tbStaffprofileService.updateTbStaffprofile(tbStaffprofileId, tbStaffprofile);
    return new ResponseEntity<ResultDTO>(new ResultOfTbStaffprofileDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbStaffprofilePO删除
   */
  @Override
  public ResponseEntity<ResultDTO> tbStaffprofilesDelete(@PathVariable String tbStaffprofileId) {
    tbStaffprofileService.deleteById(tbStaffprofileId);
    return new ResponseEntity<ResultDTO>(new ResultDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  
}