package pers.fj.staffmanage.service.staff.manage;

import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffPO;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;

/**
 * @author Hotpotmaterial-Code2 
 * 业务接口声明 - ITbStaffService
 */
public interface ITbStaffService {

  /**
   * 获取TbStaff的jsonschema
   * 
   * @return
   */
  public JsonSchema getTbStaffJsonSchema(String url);

  /**
   * datatable 分页查询
   * 
   * @param page
   * @return
   */
  public ResultPageDTO<TbStaffPO> getTbStaffList(PageDTO page);
  
  /**
   * 新增
   * 
   * @param tbStaff
   * @return
   */
  public int insertTbStaff(TbStaffPO tbStaff);
    
  /**
   * 修改
   * 
   * @param tbStaff
   * @return
   */
  public int updateTbStaff(String id, TbStaffPO tbStaff);
    
  /**
   * 根据ID查找
   *  
   * @param id
   * @return
   */
  public TbStaffPO findById(String id);
    
  /**
   * 删除
   * 
   * @param tbStaff
   */
  public int deleteById(String id);
  
}