package pers.fj.staffmanage.service.staff.manage;

import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPostPO;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;

/**
 * @author Hotpotmaterial-Code2 
 * 业务接口声明 - ITbPostService
 */
public interface ITbPostService {

  /**
   * 获取TbPost的jsonschema
   * 
   * @return
   */
  public JsonSchema getTbPostJsonSchema(String url);

  /**
   * datatable 分页查询
   * 
   * @param page
   * @return
   */
  public ResultPageDTO<TbPostPO> getTbPostList(PageDTO page);
  
  /**
   * 新增
   * 
   * @param tbPost
   * @return
   */
  public int insertTbPost(TbPostPO tbPost);
    
  /**
   * 修改
   * 
   * @param tbPost
   * @return
   */
  public int updateTbPost(String id, TbPostPO tbPost);
    
  /**
   * 根据ID查找
   *  
   * @param id
   * @return
   */
  public TbPostPO findById(String id);
    
  /**
   * 删除
   * 
   * @param tbPost
   */
  public int deleteById(String id);
  
}