package pers.fj.staffmanage.dao.staff.manage;

import java.util.List;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePOExample;

public interface TbStaffprofilePOMapper {
    int deleteByExample(TbStaffprofilePOExample example);

    int deleteByPrimaryKey(String id);

    int insert(TbStaffprofilePO record);

    int insertSelective(TbStaffprofilePO record);

    List<TbStaffprofilePO> selectByExample(TbStaffprofilePOExample example);

    TbStaffprofilePO selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TbStaffprofilePO record);

    int updateByPrimaryKey(TbStaffprofilePO record);
}