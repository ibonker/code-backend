package pers.fj.staffmanage.dto.staff.manage;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.entity.staff.manage.DictValuePO;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

 /**
  * @author Hotpotmaterial-Code2
  *  staff.manage.DictValuePO详情实体
  */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonInclude(Include.NON_NULL)
public class ResultOfDictValueDTO extends ResultDTO{

	@JsonProperty(value = "dictValue")
	@JsonPropertyDescription("dict_value对象")				
	@ApiModelProperty(value = "dict_value对象")
	private DictValuePO dictValue;
	

	public ResultOfDictValueDTO dictValue (DictValuePO dictValue){
	  this.dictValue = dictValue;
	  return this;
	}
}