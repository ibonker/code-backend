package pers.fj.staffmanage.service.staff.manage;

import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbDepartPO;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;

/**
 * @author Hotpotmaterial-Code2 
 * 业务接口声明 - ITbDepartService
 */
public interface ITbDepartService {

  /**
   * 获取TbDepart的jsonschema
   * 
   * @return
   */
  public JsonSchema getTbDepartJsonSchema(String url);

  /**
   * datatable 分页查询
   * 
   * @param page
   * @return
   */
  public ResultPageDTO<TbDepartPO> getTbDepartList(PageDTO page);
  
  /**
   * 新增
   * 
   * @param tbDepart
   * @return
   */
  public int insertTbDepart(TbDepartPO tbDepart);
    
  /**
   * 修改
   * 
   * @param tbDepart
   * @return
   */
  public int updateTbDepart(String id, TbDepartPO tbDepart);
    
  /**
   * 根据ID查找
   *  
   * @param id
   * @return
   */
  public TbDepartPO findById(String id);
    
  /**
   * 删除
   * 
   * @param tbDepart
   */
  public int deleteById(String id);
  
}