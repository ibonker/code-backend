package pers.fj.staffmanage.controller.v1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbPostDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPostPO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** 
 * 控制器的声明接口，可以与FeignClient配合使用 
 * 
 * @author Hotpotmaterial-Code2
 */
@Api(value = "TbPosts")
@RequestMapping(value = "/staffmanage/api/v1")
public interface TbPostsApi {
  
  /**
   * 实体staff.manage.TbPostPO的json-schema
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO的json-schema", notes = "实体staff.manage.TbPostPO的json-schema", response = ResultJsonSchemaDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultJsonSchemaDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts", produces = {"application/schema+json"},
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbPostsGet(HttpServletRequest req);
  /**
   * 实体staff.manage.TbPostPO新增
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO新增", notes = "实体staff.manage.TbPostPO新增", response = ResultOfTbPostDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPostDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPostsPost(@ApiParam(value = "tbPost", required = true) @RequestBody TbPostPO tbPost);
  /**
   * 实体staff.manage.TbPostPO的Excel导入
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO的Excel导入", notes = "实体staff.manage.TbPostPO的Excel导入", response = ResultOfExcelReportDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfExcelReportDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts/import/excel", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,consumes = {"multipart/form-data"},
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPostsPost(@ApiParam(value = "excelDTO", required = true)  ExcelImportDTO excelDTO);
  /**
   * 实体staff.manage.TbPostPO分页列表
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO分页列表", notes = "实体staff.manage.TbPostPO分页列表", response = ResultPageDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultPageDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts/pages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbPostsPagesPost(@ApiParam(value = "searchParams", required = true) @RequestBody PageDTO searchParams);
  /**
   * 实体staff.manage.TbPostPO详情
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO详情", notes = "实体staff.manage.TbPostPO详情", response = ResultOfTbPostDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPostDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts/{tbPostId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbPostsGET(@ApiParam(value = "tbPostId", required = true) @PathVariable String tbPostId);
  /**
   * 实体staff.manage.TbPostPO更新
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO更新", notes = "实体staff.manage.TbPostPO更新", response = ResultOfTbPostDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPostDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts/{tbPostId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.PUT)
  ResponseEntity<ResultDTO> tbPostsPut(@ApiParam(value = "tbPostId", required = true) @PathVariable String tbPostId, @ApiParam(value = "tbPost", required = true) @RequestBody TbPostPO tbPost);
  /**
   * 实体staff.manage.TbPostPO删除
   */
  @ApiOperation(value = "实体staff.manage.TbPostPO删除", notes = "实体staff.manage.TbPostPO删除", response = ResultOfTbPostDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbPostDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_posts/{tbPostId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.DELETE)
  ResponseEntity<ResultDTO> tbPostsDelete(@ApiParam(value = "tbPostId", required = true) @PathVariable String tbPostId);
  
}