package pers.fj.staffmanage.dao.staff.manage;

import java.util.List;
import pers.fj.staffmanage.entity.staff.manage.TbPartPO;
import pers.fj.staffmanage.entity.staff.manage.TbPartPOExample;

public interface TbPartPOMapper {
    int deleteByExample(TbPartPOExample example);

    int insert(TbPartPO record);

    int insertSelective(TbPartPO record);

    List<TbPartPO> selectByExample(TbPartPOExample example);
}