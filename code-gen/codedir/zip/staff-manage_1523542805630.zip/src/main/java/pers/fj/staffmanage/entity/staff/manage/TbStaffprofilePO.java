package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "tb_staffprofile")
public class TbStaffprofilePO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  
  @NotNull
  @Size(max = 255)
  @Column(name = "begin_date")
  @JsonProperty(value = "beginDate")
  @JsonPropertyDescription("")
  private String beginDate;
  
  @Size(max = 255)
  @Column(name = "email")
  @JsonProperty(value = "email")
  @JsonPropertyDescription("")
  private String email;
  
  @NotNull
  @Size(max = 255)
  @Column(name = "sex")
  @JsonProperty(value = "sex")
  @JsonPropertyDescription("")
  private String sex;
  
  @Size(max = 255)
  @Column(name = "staff_describ")
  @JsonProperty(value = "staffDescrib")
  @JsonPropertyDescription("")
  private String staffDescrib;
  
  @NotNull
  @Size(max = 255)
  @Column(name = "staff_id")
  @JsonProperty(value = "staffId")
  @JsonPropertyDescription("")
  private String staffId;
  
  @Size(max = 255)
  @Column(name = "tel")
  @JsonProperty(value = "tel")
  @JsonPropertyDescription("")
  private String tel;
  
  
}