package pers.fj.staffmanage.service.staff.manage;

import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePO;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;

/**
 * @author Hotpotmaterial-Code2 
 * 业务接口声明 - ITbStaffprofileService
 */
public interface ITbStaffprofileService {

  /**
   * 获取TbStaffprofile的jsonschema
   * 
   * @return
   */
  public JsonSchema getTbStaffprofileJsonSchema(String url);

  /**
   * datatable 分页查询
   * 
   * @param page
   * @return
   */
  public ResultPageDTO<TbStaffprofilePO> getTbStaffprofileList(PageDTO page);
  
  /**
   * 新增
   * 
   * @param tbStaffprofile
   * @return
   */
  public int insertTbStaffprofile(TbStaffprofilePO tbStaffprofile);
    
  /**
   * 修改
   * 
   * @param tbStaffprofile
   * @return
   */
  public int updateTbStaffprofile(String id, TbStaffprofilePO tbStaffprofile);
    
  /**
   * 根据ID查找
   *  
   * @param id
   * @return
   */
  public TbStaffprofilePO findById(String id);
    
  /**
   * 删除
   * 
   * @param tbStaffprofile
   */
  public int deleteById(String id);
  
}