package pers.fj.staffmanage.controller.v1.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import pers.fj.staffmanage.controller.base.BaseController;
import pers.fj.staffmanage.common.RestStatus;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbPartDTO;
import org.springframework.web.bind.annotation.RequestBody;
import pers.fj.staffmanage.service.staff.manage.ITbPartService;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPartPO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import pers.fj.staffmanage.controller.v1.TbPartsApi;

/** 
 * 控制器实现类
 * @author Hotpotmaterial-Code2
 */
@Controller
public class TbPartsApiController extends BaseController implements TbPartsApi {

  // 注入业务bean - ITbPartService
  @Autowired
  private ITbPartService tbPartService;
  
  /**
   * 实体staff.manage.TbPartPO新增
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsPost(@RequestBody TbPartPO tbPart) {
    tbPartService.insertTbPart(tbPart);
    return new ResponseEntity<ResultDTO>(new ResultOfTbPartDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO的json-schema
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsGet(HttpServletRequest req) {
    return new ResponseEntity<ResultDTO>(new ResultJsonSchemaDTO()
        .jsonSchema(tbPartService.getTbPartJsonSchema(req.getRequestURI()))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO的Excel导入
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsPost( ExcelImportDTO excelDTO) {
    return new ResponseEntity<ResultDTO>(new ResultOfExcelReportDTO().excelReport(tbPartService.importExcelTbPart(excelDTO))
        .message(RestStatus.RESULT_SUCCESS.message()).statusCode(RestStatus.RESULT_SUCCESS.code()),
        HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO分页列表
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsPagesPost(@RequestBody PageDTO searchParams) {
    return new ResponseEntity<ResultDTO>(tbPartService.getTbPartList(searchParams)
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO删除
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsDelete(@PathVariable String tbPartId) {
    tbPartService.deleteById(tbPartId);
    return new ResponseEntity<ResultDTO>(new ResultDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO更新
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsPut(@PathVariable String tbPartId, @RequestBody TbPartPO tbPart) {
    tbPartService.updateTbPart(tbPartId, tbPart);
    return new ResponseEntity<ResultDTO>(new ResultOfTbPartDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPartPO详情
   */
  @Override
  public ResponseEntity<ResultDTO> tbPartsGET(@PathVariable String tbPartId) {
    return new ResponseEntity<ResultDTO>(new ResultOfTbPartDTO()
        .tbPart(tbPartService.findById(tbPartId))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  
}