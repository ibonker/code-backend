package pers.fj.staffmanage.service.staff.manage.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.beanutils.ConversionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffprofilePOExample;
import pers.fj.staffmanage.service.staff.manage.ITbStaffprofileService;
import pers.fj.staffmanage.dao.staff.manage.TbStaffprofilePOMapper;

import org.hotpotmaterial.anywhere.common.utils.MybatisFilterUtils;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import org.hotpotmaterial.anywhere.common.utils.StringUtils;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import org.hotpotmaterial.jsonmeta.ResourceMetaManager;

import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.excel.ExcelFailedDTO;
import pers.fj.staffmanage.service.excel.IExcelOperationService;
import com.google.common.collect.Lists;

import lombok.extern.slf4j.Slf4j;

/**
 * @author Hotpotmaterial-Code2
 * 业务接口声明实现类 - TbStaffprofileServiceImpl
 */
@Service
@Slf4j
public class TbStaffprofileServiceImpl implements ITbStaffprofileService {
  
  @Autowired
  private TbStaffprofilePOMapper tbStaffprofilePOMapper;
  
  // 注入excelservice
  @Autowired
  private IExcelOperationService excelOperationService;
  
  @Autowired
  private ResourceMetaManager metaManager;
  
  // 获取json schema
  @Override
  public JsonSchema getTbStaffprofileJsonSchema(String url) {
    return metaManager.fetchJsonSchema(TbStaffprofilePO.class, url);
  }
  
  //新增
  @Override
  public int insertTbStaffprofile(TbStaffprofilePO tbStaffprofile) {
    // 设置值
    tbStaffprofile.preInsert();
    return tbStaffprofilePOMapper.insertSelective(tbStaffprofile);
  }
  
  //导入excel
  @Override
  public ExcelReportDTO importExcelTbStaffprofile(ExcelImportDTO excelDTO) {
    // 创建导入结果
    ExcelReportDTO excelReport = new ExcelReportDTO(); 
    // 创建失败结果集
    List<ExcelFailedDTO> failedList = Lists.newArrayList();
    // 导入开始时间
    Long startTime = System.currentTimeMillis();
    List<Map<String, Object>> datas = excelOperationService.importExcel(excelDTO);
    int i = 0;
    int failedCount = 0;
    int successCount = 0;
    for (Map<String, Object> data : datas) {
      TbStaffprofilePO tbStaffprofile = new TbStaffprofilePO();
      try {
        // map转换为对象
        BeanUtils.populate(tbStaffprofile, data);
        // 导入数据库
        this.insertTbStaffprofile(tbStaffprofile);
        // 记录成功导入数
        successCount++;
      } catch (IllegalAccessException | InvocationTargetException | ConversionException e) {
        // 记录失败导入数
        failedCount++;
        // 创建失败原因
        ExcelFailedDTO failed = new ExcelFailedDTO(i + 1, e.getMessage());
        // 添加结果集
        failedList.add(failed);
        log.error("导入数据失败：第" + i + "行", e);
      }
      i++; 
    }
    // 导入结束时间
    Long endTime = System.currentTimeMillis();
    
    excelReport.setTotal(i);
    excelReport.setFailedTotal(failedCount);
    excelReport.setSuccessTotal(successCount);
    excelReport.setFailedDetails(failedList);
    excelReport.setTimeCost(endTime - startTime);
    
    return excelReport;
  }
  	
  //修改
  @Override
  public int updateTbStaffprofile(String id, TbStaffprofilePO tbStaffprofile) {
    tbStaffprofile.preUpdate();
    tbStaffprofile.setId(id);
    return tbStaffprofilePOMapper.updateByPrimaryKeySelective(tbStaffprofile);
  }

  //通过id查询
  @Override
  public TbStaffprofilePO findById(String id) {
    return tbStaffprofilePOMapper.selectByPrimaryKey(id);
  }

  //通过id删除
  @Override
  public int deleteById(String id) {
    return tbStaffprofilePOMapper.deleteByPrimaryKey(id);
  }
  
  //分页查询
  @Override
  public ResultPageDTO<TbStaffprofilePO> getTbStaffprofileList(PageDTO page) {

    ResultPageDTO<TbStaffprofilePO> result = new ResultPageDTO<TbStaffprofilePO>();

    TbStaffprofilePOExample ce = new TbStaffprofilePOExample();
    // 获取json schema
    JsonSchema jsonschema = metaManager.fetchJsonSchema(TbStaffprofilePO.class, null);
    // 查询
    MybatisFilterUtils.transformForMybatis(ce.createCriteria(), page.getCollection(), jsonschema);
    // 分页
    PageHelper.startPage(page.getPageParms().getPageIndex(), page.getPageParms().getPageSize());
    // 排序
    String order = MybatisFilterUtils.transformOrderBy(page, jsonschema);
    if (!StringUtils.isEmpty(order)) {
      ce.setOrderByClause(order);
    }
    PageInfo<TbStaffprofilePO> list = new PageInfo<>(tbStaffprofilePOMapper.selectByExample(ce));

    result.setData(list.getList());
    result.setPageNumber(list.getPageNum());
    result.setPageSize(list.getPageSize());
    result.setTotalElements(list.getTotal());
    return result;
  }
  
}