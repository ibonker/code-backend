package pers.fj.staffmanage.dto.uiconfig;
	
import lombok.Data;

/**
 * 前端配置文件请求实体
 * @author Hotpotmaterial-Code2
 */
@Data
public class RequestUiConfigDTO {

  // 数据
  private String data;
  
}