package pers.fj.staffmanage.controller.v1.impl;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import pers.fj.staffmanage.controller.base.BaseController;
import pers.fj.staffmanage.common.RestStatus;
import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbPostDTO;
import pers.fj.staffmanage.service.staff.manage.ITbPostService;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPostPO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import pers.fj.staffmanage.controller.v1.TbPostsApi;

/** 
 * 控制器实现类
 * @author Hotpotmaterial-Code2
 */
@Controller
public class TbPostsApiController extends BaseController implements TbPostsApi {

  // 注入业务bean - ITbPostService
  @Autowired
  private ITbPostService tbPostService;
  
  /**
   * 实体staff.manage.TbPostPO的json-schema
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsGet(HttpServletRequest req) {
    return new ResponseEntity<ResultDTO>(new ResultJsonSchemaDTO()
        .jsonSchema(tbPostService.getTbPostJsonSchema(req.getRequestURI()))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO新增
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsPost(@RequestBody TbPostPO tbPost) {
    tbPostService.insertTbPost(tbPost);
    return new ResponseEntity<ResultDTO>(new ResultOfTbPostDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO的Excel导入
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsPost( ExcelImportDTO excelDTO) {
    return new ResponseEntity<ResultDTO>(new ResultOfExcelReportDTO().excelReport(tbPostService.importExcelTbPost(excelDTO))
        .message(RestStatus.RESULT_SUCCESS.message()).statusCode(RestStatus.RESULT_SUCCESS.code()),
        HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO分页列表
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsPagesPost(@RequestBody PageDTO searchParams) {
    return new ResponseEntity<ResultDTO>(tbPostService.getTbPostList(searchParams)
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO详情
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsGET(@PathVariable String tbPostId) {
    return new ResponseEntity<ResultDTO>(new ResultOfTbPostDTO()
        .tbPost(tbPostService.findById(tbPostId))
        .message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO更新
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsPut(@PathVariable String tbPostId, @RequestBody TbPostPO tbPost) {
    tbPostService.updateTbPost(tbPostId, tbPost);
    return new ResponseEntity<ResultDTO>(new ResultOfTbPostDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  /**
   * 实体staff.manage.TbPostPO删除
   */
  @Override
  public ResponseEntity<ResultDTO> tbPostsDelete(@PathVariable String tbPostId) {
    tbPostService.deleteById(tbPostId);
    return new ResponseEntity<ResultDTO>(new ResultDTO().message(RestStatus.RESULT_SUCCESS.message())
        .statusCode(RestStatus.RESULT_SUCCESS.code()), HttpStatus.OK);
  }
  
}