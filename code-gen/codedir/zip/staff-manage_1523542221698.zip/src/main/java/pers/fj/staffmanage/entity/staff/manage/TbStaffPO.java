package pers.fj.staffmanage.entity.staff.manage;

import javax.persistence.Column;
import javax.persistence.Table;
import pers.fj.staffmanage.common.BaseEntity;

import javax.validation.constraints.Size;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

import lombok.Data;
import lombok.EqualsAndHashCode;

/**
 * @author Hotpotmaterial-Code2
 * 实体
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Table(name = "tb_staff")
public class TbStaffPO extends BaseEntity {
  private static final long serialVersionUID = 1L;

  
  @NotNull
  @Size(max = 200)
  @Column(name = "name")
  @JsonProperty(value = "name")
  @JsonPropertyDescription("名称")
  private String name;
  
  @NotNull
  @Size(max = 1)
  @Column(name = "is_admin")
  @JsonProperty(value = "isAdmin")
  @JsonPropertyDescription("")
  private String isAdmin;
  
  @NotNull
  @Size(max = 500)
  @Column(name = "passwd")
  @JsonProperty(value = "passwd")
  @JsonPropertyDescription("")
  private String passwd;
  
  @NotNull
  @Column(name = "sort")
  @JsonProperty(value = "sort")
  @JsonPropertyDescription("")
  private Integer sort;
  
  @NotNull
  @Size(max = 64)
  @Column(name = "depart_id")
  @JsonProperty(value = "departId")
  @JsonPropertyDescription("")
  private String departId;
  
  @NotNull
  @Size(max = 64)
  @Column(name = "post_id")
  @JsonProperty(value = "postId")
  @JsonPropertyDescription("")
  private String postId;
  
  @Size(max = 10)
  @Column(name = "code")
  @JsonProperty(value = "code")
  @JsonPropertyDescription("")
  private String code;
  
  @NotNull
  @Size(max = 1)
  @Column(name = "is_active")
  @JsonProperty(value = "isActive")
  @JsonPropertyDescription("")
  private String isActive;
  
  
}