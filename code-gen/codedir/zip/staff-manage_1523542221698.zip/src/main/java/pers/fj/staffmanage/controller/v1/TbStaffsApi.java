package pers.fj.staffmanage.controller.v1;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RequestBody;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultJsonSchemaDTO;
import org.springframework.web.bind.annotation.PathVariable;
import pers.fj.staffmanage.entity.staff.manage.TbStaffPO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;
import pers.fj.staffmanage.dto.staff.manage.ResultOfTbStaffDTO;
import pers.fj.staffmanage.dto.excel.ResultOfExcelReportDTO;
import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

/** 
 * 控制器的声明接口，可以与FeignClient配合使用 
 * 
 * @author Hotpotmaterial-Code2
 */
@Api(value = "TbStaffs")
@RequestMapping(value = "/staffmanage/api/v1")
public interface TbStaffsApi {
  
  /**
   * 实体staff.manage.TbStaffPO新增
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO新增", notes = "实体staff.manage.TbStaffPO新增", response = ResultOfTbStaffDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffsPost(@ApiParam(value = "tbStaff", required = true) @RequestBody TbStaffPO tbStaff);
  /**
   * 实体staff.manage.TbStaffPO的json-schema
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO的json-schema", notes = "实体staff.manage.TbStaffPO的json-schema", response = ResultJsonSchemaDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultJsonSchemaDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs", produces = {"application/schema+json"},
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbStaffsGet(HttpServletRequest req);
  /**
   * 实体staff.manage.TbStaffPO的Excel导入
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO的Excel导入", notes = "实体staff.manage.TbStaffPO的Excel导入", response = ResultOfExcelReportDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfExcelReportDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs/import/excel", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,consumes = {"multipart/form-data"},
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffsPost(@ApiParam(value = "excelDTO", required = true)  ExcelImportDTO excelDTO);
  /**
   * 实体staff.manage.TbStaffPO分页列表
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO分页列表", notes = "实体staff.manage.TbStaffPO分页列表", response = ResultPageDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultPageDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs/pages", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.POST)
  ResponseEntity<ResultDTO> tbStaffsPagesPost(@ApiParam(value = "searchParams", required = true) @RequestBody PageDTO searchParams);
  /**
   * 实体staff.manage.TbStaffPO更新
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO更新", notes = "实体staff.manage.TbStaffPO更新", response = ResultOfTbStaffDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs/{tbStaffId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.PUT)
  ResponseEntity<ResultDTO> tbStaffsPut(@ApiParam(value = "tbStaffId", required = true) @PathVariable String tbStaffId, @ApiParam(value = "tbStaff", required = true) @RequestBody TbStaffPO tbStaff);
  /**
   * 实体staff.manage.TbStaffPO删除
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO删除", notes = "实体staff.manage.TbStaffPO删除", response = ResultOfTbStaffDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs/{tbStaffId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.DELETE)
  ResponseEntity<ResultDTO> tbStaffsDelete(@ApiParam(value = "tbStaffId", required = true) @PathVariable String tbStaffId);
  /**
   * 实体staff.manage.TbStaffPO详情
   */
  @ApiOperation(value = "实体staff.manage.TbStaffPO详情", notes = "实体staff.manage.TbStaffPO详情", response = ResultOfTbStaffDTO.class)
  @ApiResponses(
      value = {@ApiResponse(code = 200, message = "返回结果信息", response = ResultOfTbStaffDTO.class),
          @ApiResponse(code = 401, message = "返回认证错误信息")})
  @RequestMapping(value = "/tb_staffs/{tbStaffId}", produces = MediaType.APPLICATION_JSON_UTF8_VALUE,
      method = RequestMethod.GET)
  ResponseEntity<ResultDTO> tbStaffsGET(@ApiParam(value = "tbStaffId", required = true) @PathVariable String tbStaffId);
  
}