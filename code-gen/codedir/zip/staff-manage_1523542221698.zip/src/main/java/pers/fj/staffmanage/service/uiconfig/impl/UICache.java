package pers.fj.staffmanage.service.uiconfig.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pers.fj.staffmanage.common.RestStatus;
import pers.fj.staffmanage.exception.CodeCommonException;
import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.hotpotmaterial.anywhere.common.utils.StringUtils;
import pers.fj.staffmanage.entity.staff.manage.UiConfigPO;
import pers.fj.staffmanage.service.uiconfig.IUiConfigService;

import lombok.extern.slf4j.Slf4j;

/**
 * 前端配置文件缓存
 * @author Hotpotmaterial-Code2
 */
@Service
@Slf4j
public class UICache {
  
  @Autowired
  private IUiConfigService uiconfigService;

  //初始化版本号
  private int version = 0;
  
  //构建缓存容器
  private Map <String, Object> UIMap = new HashMap<>();
  
  public void saveUiMap(UiConfigPO configObj) {
    String configStr = "";
    if (configObj != null) {
      configStr = configObj.getConfigJson();
      // 读取json
      if (StringUtils.isNotBlank(configStr)) {
        // 解析文件内容到json node
        ObjectMapper mapper = new ObjectMapper();
        JsonFactory factory = mapper.getFactory();
        JsonParser parser;
        JsonNode actualObj = null;
        try {
          // 解析
          parser = factory.createParser(configStr);
          // 读取数据到JsonNode
          actualObj = mapper.readTree(parser);
        } catch (IOException e) {
          // 抛出异常
          throw new CodeCommonException(RestStatus.RESULT_SYSTEM_ERROR.code(),
              RestStatus.RESULT_SYSTEM_ERROR.message(), e);
        }
        // 放入缓存中
        UIMap.put("actualObj", actualObj);
      }
    }
    UIMap.put("version", version);
  }

  /**
   * 缓存UIconfig
   */
  @PostConstruct
  public void initUiConfig() {
    log.info(">>>>>>>> 初始化UI配置缓存 <<<<<<<<");
    // 读取数据库
    UiConfigPO configObj = uiconfigService.findById("all");
    // 保存到缓存
    this.saveUiMap(configObj);
  }
  
  /**
   * 获取缓存
   */
  public Map <String, Object> getUIMap(){
    return this.UIMap;
  }
}