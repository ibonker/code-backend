package pers.fj.staffmanage.dao.staff.manage;

import java.util.List;
import pers.fj.staffmanage.entity.staff.manage.TbPostPO;
import pers.fj.staffmanage.entity.staff.manage.TbPostPOExample;

public interface TbPostPOMapper {
    int deleteByExample(TbPostPOExample example);

    int deleteByPrimaryKey(String id);

    int insert(TbPostPO record);

    int insertSelective(TbPostPO record);

    List<TbPostPO> selectByExample(TbPostPOExample example);

    TbPostPO selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TbPostPO record);

    int updateByPrimaryKey(TbPostPO record);
}