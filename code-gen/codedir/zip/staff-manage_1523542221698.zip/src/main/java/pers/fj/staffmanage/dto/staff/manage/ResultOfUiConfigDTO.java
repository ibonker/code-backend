package pers.fj.staffmanage.dto.staff.manage;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultDTO;
import pers.fj.staffmanage.entity.staff.manage.UiConfigPO;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.ToString;

 /**
  * @author Hotpotmaterial-Code2
  *  staff.manage.UiConfigPO详情实体
  */
@Data
@EqualsAndHashCode(callSuper = true)
@ToString(callSuper = true)
@JsonInclude(Include.NON_NULL)
public class ResultOfUiConfigDTO extends ResultDTO{

	@JsonProperty(value = "uiConfig")
	@JsonPropertyDescription("ui_config对象")				
	@ApiModelProperty(value = "ui_config对象")
	private UiConfigPO uiConfig;
	

	public ResultOfUiConfigDTO uiConfig (UiConfigPO uiConfig){
	  this.uiConfig = uiConfig;
	  return this;
	}
}