package pers.fj.staffmanage.service.uiconfig;
	
import java.util.Map;
import pers.fj.staffmanage.entity.staff.manage.UiConfigPO;

/**
 * @author Hotpotmaterial-Code2
 * 前端配置文件业务接口声明（文件保存）
 */
public interface IUiConfigService {
  
  /**
   * 获取ui配置
   * @return
   */
  public Map<String, Object> getUiConfig(String version);

  /**
   * 保存ui配置
   * @param data
   */
  public void saveUiConfig(String data);

  /**
   * 获取ui数据
   * @param id
   */
  public UiConfigPO findById(String id);

  /**
   * 修改ui数据
   * @param id
   */
  public UiConfigPO updateUiConfig(UiConfigPO configObj);

  /**
   * 新增ui数据
   * @param id
   */
  public UiConfigPO insertUiConfig(String id, UiConfigPO configObj);
}