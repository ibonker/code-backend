package pers.fj.staffmanage.service.staff.manage;

import org.hotpotmaterial.anywhere.common.mvc.page.rest.request.PageDTO;
import org.hotpotmaterial.anywhere.common.mvc.rest.basic.ResultPageDTO;
import pers.fj.staffmanage.entity.staff.manage.TbPartPO;
import org.hotpotmaterial.jsonmeta.JsonSchema;
import pers.fj.staffmanage.dto.excel.ExcelReportDTO;
import pers.fj.staffmanage.dto.excel.ExcelImportDTO;

/**
 * @author Hotpotmaterial-Code2 
 * 业务接口声明 - ITbPartService
 */
public interface ITbPartService {

  /**
   * 获取TbPart的jsonschema
   * 
   * @return
   */
  public JsonSchema getTbPartJsonSchema(String url);

  /**
   * datatable 分页查询
   * 
   * @param page
   * @return
   */
  public ResultPageDTO<TbPartPO> getTbPartList(PageDTO page);
  
  /**
   * 新增
   * 
   * @param tbPart
   * @return
   */
  public int insertTbPart(TbPartPO tbPart);
    
  /**
   * 修改
   * 
   * @param tbPart
   * @return
   */
  public int updateTbPart(String id, TbPartPO tbPart);
    
  /**
   * 根据ID查找
   *  
   * @param id
   * @return
   */
  public TbPartPO findById(String id);
    
  /**
   * 删除
   * 
   * @param tbPart
   */
  public int deleteById(String id);
  
}