package pers.fj.staffmanage.dao.staff.manage;

import java.util.List;
import pers.fj.staffmanage.entity.staff.manage.TbStaffPO;
import pers.fj.staffmanage.entity.staff.manage.TbStaffPOExample;

public interface TbStaffPOMapper {
    int deleteByExample(TbStaffPOExample example);

    int deleteByPrimaryKey(String id);

    int insert(TbStaffPO record);

    int insertSelective(TbStaffPO record);

    List<TbStaffPO> selectByExample(TbStaffPOExample example);

    TbStaffPO selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(TbStaffPO record);

    int updateByPrimaryKey(TbStaffPO record);
}